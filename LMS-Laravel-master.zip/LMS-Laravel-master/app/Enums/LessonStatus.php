<?php


namespace App\Enums;


abstract class LessonStatus
{

    const ENABLED = 'enabled';
    const DISABLED = 'disabled';

}
