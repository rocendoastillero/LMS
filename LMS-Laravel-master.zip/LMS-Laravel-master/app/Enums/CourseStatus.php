<?php


namespace App\Enums;


abstract class CourseStatus
{

    const ENABLED = 'enabled';
    const DISABLED = 'disabled';

}
