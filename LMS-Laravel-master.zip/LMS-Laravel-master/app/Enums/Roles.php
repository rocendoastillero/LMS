<?php


namespace App\Enums;


abstract class Roles
{

    const TEACHER = 'Teacher';
    const ADMIN = 'Admin';
    const USER = 'User';

}
