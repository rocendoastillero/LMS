<?php


namespace LMS\Modules\Courses\Usecases\Contracts;


interface DeleteCourseUsecaseInterface
{

    public function handle(int $id);

}
