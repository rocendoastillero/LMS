<?php


namespace LMS\Modules\Courses\Usecases\Contracts;


interface CreateCourseUsescaseInterface
{

    public function handle(array $data);

}
