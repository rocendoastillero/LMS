<?php


namespace LMS\Modules\Courses\Usecases\Contracts;


interface ListCourseUsecaseInterface
{

    public function handle();
}
