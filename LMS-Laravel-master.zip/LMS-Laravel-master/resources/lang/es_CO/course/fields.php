<?php

return [
    'id' => 'ID',
    'courses' => 'Cursos',
    'name' => 'Nombre',
    'description' => 'Descripción',
    'teacher' => 'Profesor'
];
