<?php

return [
    'new' => 'Nuevo',
    'create' => 'Crear curso',
    'edit' => 'Editar',
    'update' => 'Actualizar curso',
    'delete' => 'Eliminar',
    'index' => 'Lista de cursos',
    'restore' => 'Habilitar'
];
