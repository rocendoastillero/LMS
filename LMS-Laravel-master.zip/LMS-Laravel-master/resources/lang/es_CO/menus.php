<?php
return ["administration" => "ADMIN"];
