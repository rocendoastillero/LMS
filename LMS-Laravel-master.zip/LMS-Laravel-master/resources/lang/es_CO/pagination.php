<?php
return ["next" => "Siguiente »", "previous" => "« Anterior"];
