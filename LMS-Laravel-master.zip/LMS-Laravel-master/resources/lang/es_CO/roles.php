<?php
return [
    "admin" => "Admin",
    "coordinador" => "Coordinador",
    "not_have" => "No hay roles definidos",
    "permission" => "Permiso",
    "permissions" => "Permisos",
    "role" => "Rol",
    "roles" => "Roles",
    "teacher" => "Profesor",
    "user" => "Usario"
];
