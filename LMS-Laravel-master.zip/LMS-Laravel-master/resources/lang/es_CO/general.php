<?php
return [
    "cancel" => "Cancelar",
    "close" => "Cerrar",
    "name" => "Nombre",
    "new" => "Nuevo",
    "save" => "Guardar",
    "show" => "Ver"
];
