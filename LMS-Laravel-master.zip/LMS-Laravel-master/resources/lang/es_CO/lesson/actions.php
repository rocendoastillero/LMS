<?php

return [
    'new' => 'Nuevo',
    'create' => 'Crear clase',
    'edit' => 'Editar',
    'update' => 'Actualizar clase',
    'delete' => 'Eliminar',
    'index' => 'Lista de clases',
    'restore' => 'Habilitar'
];
