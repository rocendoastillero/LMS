<?php

return [
    'id' => 'ID',
    'courses' => 'Clases',
    'title' => 'Titulo',
];
