<?php

return [
    'lessons' => 'Lecciones',
    'lesson' => 'Leccion',
    'not_have' => 'No hay lecciones definidas'
];
