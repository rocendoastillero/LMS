<?php

return [
    'id' => 'ID',
    'courses' => 'Lessons',
    'title' => 'Title',
];
