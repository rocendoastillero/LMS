<?php

return [
    'new' => 'New',
    'create' => 'Create',
    'edit' => 'Edit',
    'update' => 'Update',
    'delete' => 'Delete',
    'index' => 'List of lessons',
    'restore' => 'Recovery',
];
