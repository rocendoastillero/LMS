<?php

return [
    'lessons' => 'Lessons',
    'lesson' => 'Lessons',
    'not_have' => 'Not have lessons'
];
