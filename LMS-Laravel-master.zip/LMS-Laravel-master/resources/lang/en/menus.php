<?php
return ["administration" => "Admin"];
