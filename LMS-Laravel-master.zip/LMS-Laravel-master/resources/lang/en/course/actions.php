<?php

return [
    'new' => 'New',
    'create' => 'Create',
    'edit' => 'Edit',
    'update' => 'Update',
    'delete' => 'Delete',
    'index' => 'List of courses',
    'restore' => 'Recovery'
];
