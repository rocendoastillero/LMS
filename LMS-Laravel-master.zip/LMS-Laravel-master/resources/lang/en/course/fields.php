<?php

return [
    'id' => 'ID',
    'courses' => 'Course',
    'name' => 'Name',
    'description' => 'Description',
    'teacher' => 'Teacher'
];
