<?php
return [
    "cancel" => "Cancel",
    "close" => "Close",
    "name" => "First Name",
    "new" => "New",
    "save" => "Save",
    "show" => "Watch"
];
