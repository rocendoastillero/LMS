<?php
return [
    "admin" => "Admin",
    "coordinador" => "Coordinator",
    "not_have" => "There are no defined roles",
    "permission" => "Permission",
    "permissions" => "Permissions",
    "role" => "Role",
    "roles" => "Roles",
    "teacher" => "Teacher",
    "user" => "User"
];
